%{
-----------------------------------------------------------------
                 THE OBJECTIVE FUNCTION CODE OF 
   CONTRAST STRETCHING BASED PANSHARPENING (CSP) IN MATLAB 2022A
-----------------------------------------------------------------

load mydata
rng(100);  % Initialize mergene-twister pseudo random number generator for WDE

algo_wde('ObjFun_CSP',mydata, 5 , 7*mydata.k ,  0.00 , 255.00 , 200 , 100 ) ;
[ObjFunVal, PI ] = ObjFun_CSP( outwde.globalminimizer , mydata ) ;
montage({ uint8(mydata.MSI) uint8(PI) },'size',[1 2]), shg

%}                              

function [ ObjFunVal, PI ] = ObjFun_CSP( pattern , mydata )

N = size(pattern,1) ;          % size of pattern-matrix
ObjFunVal = rand(N,1) ;        % Reserved memory for objective function values of patterns to speed-up the Matlab

% Image Data
MSI = double(mydata.MSI) ;     % multispectral image with low spectral resolution
PI = 0 * MSI;                  % Reserved memory for PI to speed-up the Matlab
PAN = double(mydata.PAN) ;     % panchromatic image with high spatial resolution
k = mydata.k ;

% Get monochromatics image band from MSI
[ red, green , blue ] = deal( MSI(:,:,1), MSI(:,:,2), MSI(:,:,3) ) ;

for i = 1 : N

    % --------------------------------------------------------------------------------------------
    % Sequantial Evaluation of Pattern Vectors
    solution = sort( reshape( round( pattern(i,:) ) , 7 , k ) , 2 ) ;
    % --------------------------------------------------------------------------------------------
    % Nodes of Linear Contrast Stretching 
    node1 = solution( 1 , : ) ; % nodes of "1st Linear Contrast Stretching of red-image"
    node2 = solution( 2 , : ) ; % nodes of "1st Linear Contrast Stretching of green-image"
    node3 = solution( 3 , : ) ; % nodes of "1st Linear Contrast Stretching of blue-image"

    node4 = solution( 4 , : ) ; % nodes of "2nd Linear Contrast Stretching of red-image"
    node5 = solution( 5 , : ) ; % nodes of "2nd Linear Contrast Stretching of green-image"
    node6 = solution( 6 , : ) ; % nodes of "2nd Linear Contrast Stretching of blue-image"
    
    node7 = solution( 7 , : ) ; % nodes of "Linear Contrast Stretching of pan-image"
    % --------------------------------------------------------------------------------------------
    % Computation of Linear Contrast Stretched Images
    red1    = linearCS( red , node1 ) ;     % 1st Linear Contrast Stretching of red-image
    green1  = linearCS( green , node2 ) ;   % 1st Linear Contrast Stretching of green-image
    blue1   = linearCS( blue , node3 ) ;    % 1st Linear Contrast Stretching of blue-image                      
    
    red2    = linearCS( red , node4 ) ;     % 2nd Linear Contrast Stretching of red-image
    green2  = linearCS( green , node5 ) ;   % 2nd Linear Contrast Stretching of green-image
    blue2   = linearCS( blue , node6 ) ;    % 2nd Linear Contrast Stretching of blue-image    
    
    C = linearCS( PAN , node7 ) ;           % Linear Contrast Stretching of pan-image
    % --------------------------------------------------------------------------------------------
    % Generation of initPI,    
    red0    = ( red1   ./  red2   ) .* C ;  % red  of initPI
    green0  = ( green1 ./  green2 ) .* C ;  % green  of initPI
    blue0   = ( blue1  ./  blue2  ) .* C ;  % blue  of initPI
    % --------------------------------------------------------------------------------------------
    initPI = uint8(  cat( 3 , red0 , green0 , blue0 )  ) ;
    % --------------------------------------------------------------------------------------------
    % Color Transfer Operation on initPI from MSI to generate PI
    for j = 1:3 
        img = double( initPI(:,:,j) ); 
        imj = MSI(:,:,j) ; 
        img = ( ( img - mean2(img) ) / std2( img ) ) * std2(imj) + mean2(imj); 
        PI(:,:,j) = uint8(img) ; 
    end
    % --------------------------------------------------------------------------------------------
    % Objective Function Value, Root Mean Squared Error (RMSE)
    ObjFunVal(i) = sqrt( immse( uint8(MSI) , uint8(PI) ) ) ; 
    % --------------------------------------------------------------------------------------------

end






